<div class="copyright">
    <div class="text">
        <a href="#">
            (주)엠씨케이퍼블리싱 서울특별시 강남구 봉은사로 226 Tel 02.3458.7300 Fax 02.3458.7119 정기구독문의 Tel 02.3458.7122
            사업자등록번호211-86-54814 통신판매업신고제 2007-3210121-30-2-10512호 대표 손기연
            Copyright © 2017 MCK Publishing Co. Ltd. All Rights Reserved.
        </a>
    </div>
</div>

</body>
</html>