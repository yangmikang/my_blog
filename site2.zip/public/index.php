<?php
include "../part/head.php"
?>
<?php
include "../part/foot.php"
?>